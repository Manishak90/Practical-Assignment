﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PhoneNumberDetectionApp
{
    public interface IPhoneNumberDetector
    {
        bool ContainsPhoneNumber(string input);
        List<string> ExtractPhoneNumbers(string input);
    }
}

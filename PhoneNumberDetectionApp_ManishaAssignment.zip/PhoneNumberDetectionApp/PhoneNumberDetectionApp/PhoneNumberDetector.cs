﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace PhoneNumberDetectionApp
{
    public class PhoneNumberDetector : IPhoneNumberDetector
    {
        private readonly List<string> _phonePatterns = new()
        {
            @"\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}", // (123) 456-7890 or 123-456-7890
            @"\+?\d{1,2}[-.\s]?\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}", // +1-123-456-7890
            @"\d{10}", // 1234567890
            @"\+?\d{11,15}", // +911234567890
            @"(ZERO|ONE|TWO|THREE|FOUR|FIVE|SIX|SEVEN|EIGHT|NINE|ZERO)+", // English words
            @"(एक|दो|तीन|चार|पांच|छह|सात|आठ|नौ|शून्य)+", // Hindi words
            @"(ZERO|ONE|TWO|THREE|FOUR|FIVE|SIX|SEVEN|EIGHT|NINE|ZERO|एक|दो|तीन|चार|पांच|छह|सात|आठ|नौ|शून्य)+" // Combination
        };

        public bool ContainsPhoneNumber(string input)
        {
            foreach (var pattern in _phonePatterns)
            {
                if (Regex.IsMatch(input, pattern, RegexOptions.IgnoreCase))
                {
                    return true;
                }
            }
            return false;
        }

        public List<string> ExtractPhoneNumbers(string input)
        {
            var phoneNumbers = new List<string>();
            foreach (var pattern in _phonePatterns)
            {
                var matches = Regex.Matches(input, pattern, RegexOptions.IgnoreCase);
                foreach (Match match in matches)
                {
                    phoneNumbers.Add(match.Value);
                }
            }
            return phoneNumbers;
        }
    }
}

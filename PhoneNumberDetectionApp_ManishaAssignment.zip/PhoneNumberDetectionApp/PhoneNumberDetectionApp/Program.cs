﻿using Microsoft.Extensions.DependencyInjection;
using System;

namespace PhoneNumberDetectionApp
{
    class Program
    {
        static void Main(string[] args)
        {
            var serviceProvider = new ServiceCollection()
                .AddSingleton<IPhoneNumberDetector, PhoneNumberDetector>()
                .BuildServiceProvider();

            var detector = serviceProvider.GetService<IPhoneNumberDetector>();

            Console.WriteLine("Welcome to the Phone Number Detection Application.");
            Console.WriteLine("Please enter your message below:");

            string inputMessage = Console.ReadLine();

            if (detector.ContainsPhoneNumber(inputMessage))
            {
                Console.WriteLine();
                Console.WriteLine("Warning: Your message contains a phone number. Please remove it and try again.");
                var detectedNumbers = detector.ExtractPhoneNumbers(inputMessage);
                Console.WriteLine("Detected phone numbers:");
                foreach (var number in detectedNumbers)
                {
                    Console.WriteLine($"- {number}");
                }
            }
            else
            {
                Console.WriteLine();
                Console.WriteLine("Your message is acceptable and does not contain any phone numbers.");
            }

            Console.WriteLine();
            Console.WriteLine("Thank you for using the Phone Number Detection Application.");
        }
    }
}